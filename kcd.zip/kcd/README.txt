KCD TAI website package

All original page text, team names, #PKMKB, social buttons/links, copyright, styles, and particle animation are preserved. Only the background was switched from YouTube iframe to a local HTML5 video.

SETUP:
1. Put your downloaded video in the video folder.
2. Rename it exactly: background.mp4
3. Upload index.html and the video folder together to your hosting.
4. The file path must be video/background.mp4.
